ROSA BAKEHOUSE — DEMO
Open index.html in a browser to preview.

Important:
- This is a presentation demo, not the final website.
- The menu, prices, photos, logo, address, social links and business details should be replaced with Rosa Bakehouse's approved information before launch.
- WhatsApp button currently uses the publicly listed number found for Rosa Bakehouse: +234 803 915 0404.
